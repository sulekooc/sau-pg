﻿/**************************************************************************************************************************************
** SAKARYA ÜNİVERSİTESİ                                                                            
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ                                
** BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ                                                                   
** NESNEYE DAYALI PROGRAMLAMA DERSİ                                               
** 2020-2021 BAHAR DÖNEMİ                                                             
**                                                                                             
**	ÖDEV NUMARASI..........: 01 SORU.1                                                                                          
**	ÖĞRENCİ ADI............: ŞULE KOÇ                                                              
**	ÖĞRENCİ NUMARASI.......: B201210093                                                                                         
**  DERSİN ALINDIĞI GRUP...: C GRUBU
**                                                                                             
**************************************************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;

namespace EightCastles
{
    class Program
    {
        static void Main(string[] args)
        {
            var board = new Chessboard();
            Explore(board);
            Console.ReadLine();
        }

        static int resIdx = 1;
        static void Explore(Chessboard board)
        {
            // Kaleleri yerlestirme sirai, tekrarlanan kombinasyonlar disinda her zaman yukaridan sag alta dogrudur.
            var minPos = board.CastlePositions.Any() ? board.CastlePositions.Max() : 0;
            foreach (var pos in board.Slots.Where(o => o > minPos))
            {
                var newBoard = new Chessboard(board, pos);
                if (newBoard.TouchDown)
                {
                    Console.WriteLine($"// Solution {resIdx++:00}");
                    newBoard.Print();
                    Console.WriteLine();
                }
                else if (!newBoard.NoSolution)
                {
                    Explore(newBoard);
                }
            }
        }
    }

    public class Chessboard
    {
        const int GRID_SIZE = 8;
        const int DIG_SHIFT = 10;
        const int QUOTA = 8;
        
        /// Satranc tahtasi alani
       
        public HashSet<int> Slots { get; set; }
        
        /// Kalenin konumu
        
        public List<int> CastlePositions { get; set; }
        
        /// Bos Satranc tahtasi 
        
        public Chessboard()
        {
            // Izgara koordinat dizisi olustur11,12, ..., 18,21,22 ... 28, ... 88
            Slots = new HashSet<int>(
                    Enumerable.Range(1, GRID_SIZE)
                        .SelectMany(x => Enumerable.Range(1, GRID_SIZE)
                        .Select(y => x * DIG_SHIFT + y))
                    );
            CastlePositions = new List<int>();
        }
       
        /// Mevcut satranc tahtasi, kraliceyi yeni bir satranc tahtasi olusturmak icin belirli bir konuma yerlestirir.
        
        /// <param name="board">mevcutsatranctahtasi</param>
        /// <param name="pos">kaleninkonumu</param>
        public Chessboard(Chessboard board, int pos)
        {
            Slots = new HashSet<int>(board.Slots.Except(new int[] { pos }));
            CastlePositions = new List<int>(board.CastlePositions.Concat(new int[] { pos }));
            var qX = pos / DIG_SHIFT;
            var qY = pos % DIG_SHIFT;
            Action<int, int> removeSlot = (px, py) =>
            {
                // alan disindaysa yok say
                if (px < 1 || px > GRID_SIZE || py < 1 || py > GRID_SIZE) return;
                var v = px * DIG_SHIFT + py;
                if (Slots.Contains(v)) Slots.Remove(v);
            };
            for (var x = 1; x <= GRID_SIZE; x++)
            {
                for (var y = 1; y <= GRID_SIZE; y++)
                {
                    removeSlot(x, qY); // yatay cizgi
                    removeSlot(qX, y); // dikey cizgi
                }
                var tx = x + (qX - qY);
                removeSlot(tx, x); // sol üst ve sag alt egik cizgi
                tx = qX + qY - x;
                removeSlot(tx, x); // sag üst ve sol alt egik cizgi
            }
        }
        
        /// bosluk sayisi yerlestirilmemis kalelerin sayısından az ise cözüm yok
        
        public bool NoSolution => Slots.Count < QUOTA - CastlePositions.Count;
        
        /// kale sayısı kosulları sagliyor
        
        public bool TouchDown => QUOTA == CastlePositions.Count;
        // satranc tahtasini yazdir
        public void Print()
        {
            for (var y = 1; y <= GRID_SIZE; y++)
            {
                for (var x = 1; x <= GRID_SIZE; x++)
                {
                    var pos = x * DIG_SHIFT + y;
                    if (CastlePositions.Contains(pos))
                    {
                        Console.Write("C");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                    //Console.Write(" ");
                }
                Console.WriteLine();
            }
        }
    }
}