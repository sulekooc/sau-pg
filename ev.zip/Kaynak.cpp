/****************************************************************************
**					           SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				           B�LG�SAYAR M�HEND�SL��� B�L�M�
**				              PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�....:2
**				��RENC� ADI.......:�ule Ko�
**				��RENC� NUMARASI..:B201210093
**				DERS GRUBU........:B
****************************************************************************/

#include <iostream>
#include <Windows.h>// gotoxy icin

using namespace std;
void gotoxy(int x, int y);
//deger dondurmemesi icin void fonksiyonu atandi

class kat
{// kat adinda class olusturuldu
public:
	int x;
	int y;
	int  weight;
	int height;
	//kat olusturulmasi icin gerekli olan degiskenler atandi
	void olustur(int x, int y, int  weight, int height) {
		//int degerleri ile fonksiyon degerlerinin karismamasi icin pointer atandi
		this->x = x;
		this->y = y;
		this->weight = weight;
		this->height = height;
	}

	void ciz() {
		//cizilecek nesnenin x ekseninde yanyana yazdirilmasini saglayan d�ng�
		for (int i = 0; i < weight; i++) {  // evin tavani 
			gotoxy(x + i, y);
			cout << char(219);
		}
		//cizilecek nesnenin y ekseninde yanyana yazdirilmasini saglayan d�ng�
		for (int satir = 0; satir < height; satir++) {// duvarlari cizer
			gotoxy(x, y + 1 + satir);
			cout << char(219);// sol duvar

			gotoxy(x + weight - 1, y + 1 + satir); // duvarlar arasi bosluk

			cout << char(219);// sag duvar
		}
		//cizilecek nesnenin x ekseninde yanyana yazdirilmasini saglayan d�ng�
		for (int i = 0; i < weight; i++) {  // evin tabani
			gotoxy(x + i, y + height);
			cout << char(219);
		}
	}
};

class cati
{// cati adinda class olusturuldu
public:
	int x;
	int y;
	int  weight;
	int height;
	//cati olusturulmasi icin gerekli olan degiskenler atandi
	void olustur(int x, int y, int  weight, int height) {
		//int degerleri ile fonksiyon degerlerinin karismamasi icin pointer atandi
		this->x = x;
		this->y = y;
		this->weight = weight;
		this->height = height;
	}

	void ciz() {
		// cizilecek nesnenin satir atlamasini saglayan dongu
		for (int satir = 0; satir < height; satir++) {
			gotoxy(x + height - 1 - satir, y + satir);

			for (int sutun = 0; sutun < weight - 2 * (height - 1 - satir); sutun++)
				cout << char(42);
		}
	}
};

class kapi
	// kapi adinda class olusturuldu
{
public:
	int x;
	int y;
	int weight;
	int height;
	//kapi olusturulmas� icin gerekli olan degiskenler atandi

	void kapiOlustur(int x, int y, int  weight, int height) {
		//int degerleri ile fonksiyon degerlerinin karismamasi icin pointer atandi
		this->x = x;
		this->y = y;
		this->weight = weight;
		this->height = height;
	}

	void ciz() {
		// cizilecek nesnenin satir atlamasini saglayan dongu
		for (int satir = 0; satir < height; satir++) {
			gotoxy(x, y + satir);
			for (int sutun = 0; sutun < weight; sutun++)
				cout << "#";
		}
	}
};


class ev {
	// ev adinda class olusturuldu
public:
	cati cati;
	kat kat;
	kapi kapi;
	//ev olusturulmasi icin gerekli olan degiskenler atandi

	void olustur(int x, int y, int genislik, int yukseklik, int catiYukseklik) {
		//hangi nesne icin hangi degiskenlerin nasil kullanilacagi belirlendi
		cati.olustur(x, y, genislik, catiYukseklik);
		kat.olustur(x, y + catiYukseklik, genislik, yukseklik);
		kapi.kapiOlustur(x + genislik / 2, y + catiYukseklik + yukseklik - yukseklik / 2 + 1, genislik / 3, yukseklik / 2);
		
	}
	void ciz() {
		//cati,kat ve kapi cizdirildi
		cati.ciz();
		kat.ciz();
		kapi.ciz();
	}
};

int main()
{
	int x , y , genislik , yukseklik , catiYukseklik;
	//kullanicidan tan�mlanan veriler icin deger atanmasi istenildi

	cout << "X kooardinatini giriniz  :";
	cin >> x;
		cout << "Y kooardinatini giriniz  :";
		cin >> y;
		cout << "Genisligi giriniz : ";
			cin >> genislik;
		cout << "Yuksekligi giriniz  :";
		cin >> yukseklik;
		cout << "Cati yuksekligini giriniz  :";
		cin >> catiYukseklik;
			
	
	ev ev;
	ev.olustur(x, y, genislik, yukseklik, catiYukseklik);
	ev.ciz();


	gotoxy(0, 0); cout << ev.kapi.height;
	system("pause");
	return 0;
}

void gotoxy(int x, int y)
{//Komut satirinda istenilen koordinata gitmek icin fonksiyon tan�mlandi 
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}